import express from "express";
const app = express();
import dotenv from "dotenv"
import Connection from "./db/connection.js";
import patientRouter from "./routes/patientRoute.js";
import doctorRouter from "./routes/doctorRoute.js";
import adminRouter from "./routes/admninRouter.js";
import cookieParser from "cookie-parser";
import cors from "cors";
import appointmentRouter from "./routes/appointmentRoute.js";

dotenv.config();


Connection()

app.use(cors({
  origin: "http://localhost:5173",
  credentials: true,
}))

app.use(express.json())
app.use(cookieParser())
app.use("/api/patient", patientRouter)
app.use("/api/doctor", doctorRouter)
app.use("/api/admin", adminRouter)
app.use("/api/appointment",appointmentRouter)

const port = process.env.PORT

app.listen(port, ()=>{
    console.log(`server running on port ${port} `)
})