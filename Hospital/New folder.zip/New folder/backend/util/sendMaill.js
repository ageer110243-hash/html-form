import nodemailer from "nodemailer";

const sendEmail = async (options) => {
  try {
    
    const transporter = nodemailer.createTransport({
    service: process.env.SMTP_SERVICE, // e.g., 'gmail'
    auth: {
      user: process.env.SMTP_MAIL,
      pass: process.env.SMTP_PASSWORD,
    },
  });

  // Connection/Auth check karein
  await transporter.verify();

  const emailOptions = {
    from: process.env.SMTP_MAIL,
    to: options.email,
    subject: options.subject,
    text: options.message,
  };

  await transporter.sendMail(emailOptions);
  } catch (error) {

    console.log(error)
    
  }
};

export { sendEmail };