import jwt from "jsonwebtoken";
import Doctor from "../models/doctorModel.js";
import Patient from "../models/patientModel.js";
import Admin from "../models/adminModel.js";

const isAuthenticatedUser = async (req, res, next) => {
  try {
    const token = req.cookies?.token;

    if (!token) {
      return res.status(401).json({
        success: false,
        message: "Plz Login First"
      });
    }

    const decodedData = jwt.verify(token, process.env.SECRET_KEY);

    let user;
    if (decodedData.role === "doctor") {
      user = await Doctor.findById(decodedData.id);
    } else if (decodedData.role === "patient") {
      user = await Patient.findById(decodedData.id);
    } else if (decodedData.role === "admin") {
      user = await Admin.findById(decodedData.id);
    }

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not Found"
      });
    }

    // Pass user and role safely to req
    req.user = user;
    req.userRole = decodedData.role; 

    next();

  } catch (error) {
    console.log(error);
    return res.status(500).json({
      success: false,
      message: "Authentication Failed",
      error: error.message
    });
  }
};

const authorizeRoles = (...roles) => {
  return (req, res, next) => {
    // Check role safely using req.userRole or req.user.role
    const currentRole = req.userRole || req.user?.role;

    if (!currentRole || !roles.includes(currentRole)) {
      return res.status(403).json({
        success: false,
        message: `Role (${currentRole}) is not allowed to access this resource`
      });
    }

    next();
  };
};

export { isAuthenticatedUser, authorizeRoles };