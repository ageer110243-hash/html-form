const sendToken =(user, statusCode , res, message)=>{

    const token = user.getJWT();

    const options= {
        expires : new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        httpOnly: true
        }

        res.status(statusCode).cookie("token", token, options).json({
            success: true,
            message,
            token,
            user
        })
}

export {sendToken}