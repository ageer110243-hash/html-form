import express from "express"
import Patient from "../models/patientModel.js"
import { deletePatient, getallPatients, loginPatient, patientLogout, patientProfile, registerPatient, resetPassword, resetPasswordRequest, updatePasswordPatient, updatePatient } from "../controllers/patientControlles.js"
import { authorizeRoles, isAuthenticatedUser } from "../util/userAuth.js"

const patientRouter = express.Router()

patientRouter.post("/register-patient", registerPatient)
patientRouter.post("/login-patient", loginPatient)
patientRouter.get("/profile",isAuthenticatedUser, patientProfile)
patientRouter.put("/patient-update/:id",isAuthenticatedUser, updatePatient)
patientRouter.delete("/patient-delete/:id",isAuthenticatedUser, deletePatient)
patientRouter.get("/getAll-patient",isAuthenticatedUser, authorizeRoles("admin","doctor"), getallPatients)
patientRouter.post("/logout", isAuthenticatedUser, patientLogout)
patientRouter.post("/reset-password-request", resetPasswordRequest)
patientRouter.put("/reset-password/:token", resetPassword)
patientRouter.put("/update-password", isAuthenticatedUser, updatePasswordPatient )


export default patientRouter;