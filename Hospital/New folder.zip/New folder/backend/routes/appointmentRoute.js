import express from "express"
import { authorizeRoles, isAuthenticatedUser } from "../util/userAuth.js";
import { appointmentDetail, approveAppointment, bookAppointment, cancelAppointment, deleteAppointment, findAppointmentStatus, getALLApoinment, getDoctorAppointments, getPatientAppointments, rejectAppointment, updateAppointmentStatus } from "../controllers/appointment.js";


const appointmentRouter = express.Router()

appointmentRouter.post("/book", isAuthenticatedUser, authorizeRoles("patient"), bookAppointment)
appointmentRouter.get("/patient", isAuthenticatedUser, authorizeRoles("patient"), getPatientAppointments)
appointmentRouter.get("/doctor", isAuthenticatedUser,authorizeRoles("doctor"), getDoctorAppointments)
appointmentRouter.put("/approve/:id", isAuthenticatedUser, authorizeRoles("doctor"),approveAppointment)
appointmentRouter.put("/reject/:id", isAuthenticatedUser, authorizeRoles("doctor"), rejectAppointment)
appointmentRouter.put("/cancle/:id", isAuthenticatedUser, authorizeRoles("patient"), cancelAppointment)
appointmentRouter.get("/allApointment", isAuthenticatedUser, authorizeRoles("admin"), getALLApoinment)
appointmentRouter.get("/:id", isAuthenticatedUser, authorizeRoles("admin"), appointmentDetail)
appointmentRouter.get("/status/:status", isAuthenticatedUser, authorizeRoles("admin"), findAppointmentStatus)
appointmentRouter.put("/update/:id", isAuthenticatedUser, authorizeRoles("admin"), updateAppointmentStatus)
appointmentRouter.delete("/delete/:id", isAuthenticatedUser, authorizeRoles("admin"), deleteAppointment)





export default appointmentRouter;