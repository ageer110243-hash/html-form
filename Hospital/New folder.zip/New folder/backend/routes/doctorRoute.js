import express from "express"
import doctor from "../models/doctorModel.js"
import { deleteDoctorProfile, doctorLogout, doctorProfile, getAllDoctors, loginDoctor, registerDoctor, resetPasswordDoctor, resetPasswordRequest, updateDoctorProfile, updatePasswordDoctor } from "../controllers/doctorController.js"
import { authorizeRoles, isAuthenticatedUser } from "../util/userAuth.js"

const doctorRouter = express.Router()

doctorRouter.post("/register-doctor", registerDoctor)
doctorRouter.post("/login-doctor", loginDoctor)
doctorRouter.get("/profile", isAuthenticatedUser, doctorProfile)
doctorRouter.put("/update/:id", isAuthenticatedUser, updateDoctorProfile)
doctorRouter.delete("/delete/:id",isAuthenticatedUser, deleteDoctorProfile)
doctorRouter.get("/getall-doctors", getAllDoctors)
doctorRouter.post("/logout", isAuthenticatedUser, doctorLogout)
doctorRouter.post("/reset-password-request", resetPasswordRequest)
doctorRouter.put("/reset-password/:token", resetPasswordDoctor)
doctorRouter.put("/update-password" , isAuthenticatedUser, updatePasswordDoctor)

 export default doctorRouter;