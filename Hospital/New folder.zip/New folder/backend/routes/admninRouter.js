import express from "express";
import { adminDelete, adminLogout, adminProfile, adminRegister, approvedDoctor, loginAdmin, pendingDoctors, rejectDoctor, resetPasswordAdmin, resetPasswordRequest, updateAdmin, updatePasswordAdmin } from "../controllers/adminController.js";
import { authorizeRoles, isAuthenticatedUser } from "../util/userAuth.js";
const adminRouter = express.Router()

adminRouter.post("/register", adminRegister)
adminRouter.post("/login", loginAdmin)
adminRouter.put("/update/:id", isAuthenticatedUser, updateAdmin)
adminRouter.get("/profile",isAuthenticatedUser, adminProfile)
adminRouter.delete("/delete/:id", isAuthenticatedUser, adminDelete)
adminRouter.post("/logout", isAuthenticatedUser, adminLogout)
adminRouter.post("reset-password-request",resetPasswordRequest)
adminRouter.put("/reset-password/:token", resetPasswordAdmin)
adminRouter.put("/update-password", isAuthenticatedUser, updatePasswordAdmin)
adminRouter.post("/approve-doctor/:id", isAuthenticatedUser, authorizeRoles("admin"), approvedDoctor )
adminRouter.post("/reject-doctor/:id", isAuthenticatedUser, authorizeRoles("admin"), rejectDoctor)
adminRouter.get("/pending-doctors", isAuthenticatedUser, authorizeRoles("admin"), pendingDoctors)
export default adminRouter;