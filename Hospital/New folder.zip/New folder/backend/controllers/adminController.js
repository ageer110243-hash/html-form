import Admin from "../models/adminModel.js";
import Doctor from "../models/doctorModel.js";
import { sendToken } from "../util/jwtToken.js";
import { sendEmail } from "../util/sendMaill.js";

const adminRegister = async (req, res) => {
    try {
        const { name, email, password } = req.body;

        if (!name || !email || !password) {
            return res.status(400).json({
                success: false,
                message: "All inputs are required"
            });
        }

        const exitAdmin = await Admin.findOne({ email });

        if (exitAdmin) {
            return res.status(400).json({
                success: false,
                message: "Email is already registered"
            });
        }

        const admin = await Admin.create({
            name,
            email,
            password
        });

        const message = "Admin registered successfully";
        sendToken(admin, 201, res, message);

    } catch (error) {
        console.log(error);
        return res.status(500).json({
            success: false,
            message: error.message || "Internal Server Error",
            error
        });
    }
};

const loginAdmin = async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({
                success: false,
                message: "All inputs are required"
            });
        }

        const admin = await Admin.findOne({ email }).select("+password");

        if (!admin) {
            return res.status(400).json({
                success: false, // Fix: success ko false kiya
                message: "Admin Not Found"
            });
        }

        // Fix: Admin (Model) ki jagah admin (instance) use kiya
        const isPasswordMatched = await admin.comparePassword(password);

        if (!isPasswordMatched) {
            return res.status(400).json({
                success: false,
                message: "Invalid credentials"
            });
        }

        const message = "User logged in successfully";
        sendToken(admin, 200, res, message);

    } catch (error) {
        console.log(error);
        return res.status(500).json({
            success: false,
            message: error.message || "Internal Server Error",
            error
        });
    }
};

const adminProfile = async (req, res) => {
    try {
        const admin = await Admin.findById(req.user.id);

        if (!admin) {
            return res.status(400).json({
                success: false,
                message: "Admin not found"
            });
        }

        return res.status(200).json({
            success: true,
            admin
        });

    } catch (error) {
        console.log(error);
        return res.status(500).json({
            success: false,
            error
        });
    }
};

const updateAdmin = async (req, res) => {
    try {
        const admin = await Admin.findByIdAndUpdate(req.user.id, req.body, {
            runValidators: true,
            new: true
        });

        if (!admin) {
            return res.status(400).json({
                success: false,
                message: "Admin Not Found"
            });
        }

        return res.status(200).json({
            success: true,
            message: "Admin updated successfully",
            admin,
        });

    } catch (error) {
        console.log(error);
        return res.status(500).json({
            success: false,
            error
        });
    }
};

// Fix: Parameters ko (req, res) kiya
const adminDelete = async (req, res) => {
    try {
        const admin = await Admin.findByIdAndDelete(req.user.id);

        if (!admin) {
            return res.status(400).json({
                success: false,
                message: "Admin not found"
            });
        }

        return res.status(200).json({
            success: true,
            message: "Admin deleted successfully"
        });

    } catch (error) {
        console.log(error);
        return res.status(500).json({
            success: false,
            error
        });
    }
};

const adminLogout = async (req, res) => {
    try {
        res.cookie("token", null, {
            expires: new Date(Date.now()),
            httpOnly: true
        });

        return res.status(200).json({
            success: true,
            message: "Admin logged out successfully"
        });
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            success: false,
            error
        });
    }
};

const resetPasswordRequest = async (req, res) => {
    try {
        const { email } = req.body;
        const admin = await Admin.findOne({ email });

        if (!admin) {
            return res.status(400).json({
                success: false,
                message: "User not found"
            });
        }

        let resetToken = admin.resetPassword();
        await admin.save();

        const resetPasswordUrl = `http://localhost:5173/reset-password/${resetToken}`;

        const message = `If you want to reset your password click on the link: ${resetPasswordUrl}`;

        await sendEmail({
            email: admin.email,
            subject: "Reset Password Request",
            message
        });

        return res.status(200).json({
            success: true,
            message: `Email sent successfully to ${admin.email}`
        });

    } catch (error) {
        console.log(error);
        return res.status(500).json({
            success: false,
            error
        });
    }
};
const resetPasswordAdmin = async (req, res) => {
    try {
        const resetPasswordToken = crypto.createHash("sha256").update(req.params.token).digest("hex");

        const admin = await Admin.findOne({
            resetPasswordToken,
            resetPasswordExpire: { $gt: Date.now() }
        })

        if (!admin) {
            return res.status(400).json({
                success: false,
                message: "invalid token"
            })
        }

        const { password, confrimPassword } = req.body;
        if (password !== confrimPassword) {
            return res.status(400).json({
                success: false,
                message: "password does not match with each other"
            })
        }

        admin.password = password
        admin.resetPasswordExpire = undefined
        admin.resetPasswordToken = undefined

        await admin.save()

        const message = "password reset successfuly"
        sendToken(patient, 200, res, message)




    } catch (error) {
        console.log(error)
        return res.status(500).json({
            success: false,
            error

        })

    }
}

const updatePasswordAdmin = async (req, res) => {
    try {

        const { oldPassword, newPassword, confrimNewPassword } = req.body
        const admin = await Admin.findById(req.user.id)

        if (!admin) {
            return res.status(400).json({
                success: false,
                message: " User Not Found"
            })
        }

        if (newPassword !== confrimNewPassword) {
            return res.status(400).json({
                success: false,
                message: "Password not Match with Each other"
            })
        }



        admin.password = newPassword
        await admin.save()


        const message = "Password Update succussfuly"
        sendToken(patient, 200, res, message)

    } catch (error) {

        console.log(error)
        return res.status(500).json({
            success: false,
            error

        })
    }
}

const approvedDoctor = async (req, res) => {
    try {

        const doctor = await Doctor.findById(req.params.id)
        if (!doctor) {
            return res.status(400).json({
                success: false,
                message: "Doctor not Found"
            })
        }

        if (doctor.status === "Approved") {
            return res.status(200).json({
                success: false,
                message: "Doctor is Already Approved"
            })
        }

        doctor.status = "Approved"
        await doctor.save()

        return res.status(200).json({
            success: true,
            message: " Doctor Approved successfuly"
        })

    } catch (error) {
        console.log(error)

        return res.status(500).json({
            success: false,
            error
        }
        )

    }
}

const rejectDoctor = async (req, res) => {
    try {

        const { id } = req.params

        const doctor = await Doctor.findById(id)

        if (!doctor) {
            return res.status(400).json({
                success: false,
                message: "Doctor not Found"

            })
        }

        await Doctor.findByIdAndDelete(id)
        return res.status(200).json({
            success: true,
            message: "Application Rejected Successfuly"
        })

    } catch (error) {
        console.log
        return res.status(500).json({
            success: true,
            error
        })
    }
}

const pendingDoctors = async (req, res) => {
    try {

        const doctors = await Doctor.find({
            status: "pending"
        })
        if (!doctors) {
            return res.status(400).json({
                success: false,
                message: "Doctors not Found"
            })
        }

        return res.status(200).json({
            success: true,
            doctors
        }
        )

    } catch (error) {

        console.log(error)
        return res.status(500).json({
            success: false,
            error
        })
    }
}

export {
    adminRegister,
    loginAdmin,
    adminProfile,
    updateAdmin,
    adminDelete,
    adminLogout,
    resetPasswordRequest,
    resetPasswordAdmin,
    approvedDoctor,
    rejectDoctor,
    pendingDoctors,
    updatePasswordAdmin
};