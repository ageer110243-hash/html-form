import Doctor from "../models/doctorModel.js";
import { sendToken } from "../util/jwtToken.js";
import { sendEmail } from "../util/sendMaill.js";

const registerDoctor = async (req, res)=>{
    try {
        
   const {name,  email,  password,  phone,   specialization,  license, age,  experience,  gender, status} = req.body


   if(!name ||!email ||!password ||!phone ||!specialization ||!license ||!age ||!experience ||!gender ){
    return res.status(400).json({
        success: true,
        message: "all input are required"
    })
   }

   const exitingDoctor = await Doctor.findOne({
    $or : [{email}, {license}]
   })
   if(exitingDoctor){
    return res.status(400).json({
        success: true,
        message: "email are already register"
    })
   }

   const doctor = await Doctor.create({
    name,
    email,
    phone,
    password,
    specialization,
    license,
    age,
    experience,
    gender,

   })

  const message =  "your profile is in pendding lets wait for approved"
   return res.status(200).json({
    succes: true,
    message
   })

    } catch (error) {
        console.log(error)
        return res.status(500).json({
            success: false,
            error
        })
    }
}

const loginDoctor = async (req, res)=>{
try {
    
    const {email, password} = req.body
    if(!email ||!password){
        return res.status(400).json({
            success : true,
            message: "all input are required"
        })
    }
    
    const doctor = await Doctor.findOne({email})
    if(!doctor){
        return res.status(400).json({
            success: false,
            message: "invalid credentials"
        })
    }

    const passwordMatched = await doctor.comparePassword(password);
  if(!passwordMatched){

    return res.status(400).json({
        success: false,
        message: "invalid Crendentials"
    })
  };

  if(doctor.status !== "Approved"){
    return res.status(200).json({
        succes: true,
        message: "your status in still pending, plz for approval"
    })
  }
 
  const message = "doctor login successfuly"
  sendToken(doctor, 200, res, message)

} catch (error) {
    console.log(error)
    return res.status(500).json({
        success: false,
        error,
    })
}
}
const doctorProfile = async (req, res) =>{
    try {
         
        const doctor = await Doctor.findById(req.user.id)
        if(!doctor){
            return res.status(400).json({
                success: false,
                message: "doctor not found"
            })
        }

        return res.status(200).json({
            success: true,
            doctor,
        })
        

    } catch (error) {
        console.log(error)
        return res.status(500).json({
            success: false,
            error
        })
    }
}

const updateDoctorProfile = async (req, res)=>{
    try {
       const doctor = await Doctor.findByIdAndUpdate(req.user.id, req.body,{
        runValidators : true,
        new: true
        })

        if(!doctor){
            return res.status(400).json({
                success: false,
                message: "Doctor not found"
            })
        }

        return res.status(200).json({
            success: true,
            message: "doctor Profile Update Successfuly",
            doctor
        })
   

    } catch (error) {
        console.log(error)
        return res.status(500).json({
            success: false,
            error
        })
    }
}

const deleteDoctorProfile = async(req, res)=>{
  try {
     
    const doctor = await Doctor.findByIdAndDelete(req.user.id)
    if(!doctor){
        return res.status(400).json({
            success: false,
            message: "Doctor not found"
        })
    }
    return res.status(200).json({
        success: true,
        message: " Doctor Delete Successfuly"
    })

  } catch (error) {
    console.log(error)
    return res.status(500).json({
        success: false,
        error,
    } )
  }
}

const getAllDoctors = async(req, res)=>{
    try {
        const doctors = await Doctor.find()
        if(!doctors){
            return res.status(400).json({
                success: false,
                message:  "Doctors Not Found"
            })
        }
     
        return res.status(200).json({
            success: true,
            doctors
        })

    } catch (error) {
        console.log(error)
        return res.status(500).json({
            success: false,
            error,
        })

    }
}
const doctorLogout = async(req, res)=>{
    try {
        res.cookie("token", null, {
            expires : new Date(Date.now()),
            httpOnly: true
        })
 
        return res.status(200).json({
            succes: true,
            message: "Doctor loggedout successfully"
        })
    } catch (error) {
        console.log(error)
        return res.status(500).json({
            succes: false,
            error
        })
    }
}


const resetPasswordRequest = async (req, res)=>{
    try {
        
        const {email} = req.body
        const doctor = await Doctor.findOne({email})
          
        if(!doctor){
            return res.status(400).json({
                success: false,
                message: "User not Found"
            })
        }    

       let resetToken = doctor.resetPassword() ;
       await doctor.save()

       const resetPasswordUrl = `http://localhost:5173/reset-password/${resetToken}`

       const message= `if you want to reset your Password click on above link ${resetPasswordUrl}`
       await sendEmail({
        email: doctor.email,
        subject : " ResetPassword Request",
        message
       })

       return res.status(200).json({
        success: true,
        message: `Email sent successfully to ${doctor.email} `
       })

    } catch (error) {
        console.log(error)
        return res.status(500).json({
            success: false,
            error
        })
    }
}
  const resetPasswordDoctor = async (req, res) =>{
    try {
        const resetPasswordToken = crypto.createHash("sha256").update(req.params.token).digest("hex");

        const doctor = await Doctor.findOne({
            resetPasswordToken,
            resetPasswordExpire :{ $gt : Date.now()}
        })

        if(!doctor){
            return res.status(400).json({
                success: false,
                message: "invalid token"
            })
        }

        const { password, confrimPassword} = req.body;
        if(password !== confrimPassword){
            return res.status(400).json({
                success: false,
                message: "password does not match with each other"
            })
        }

        doctor.password = password
        doctor.resetPasswordExpire = undefined
        doctor.resetPasswordToken = undefined

        await doctor.save()
        
        const message = "password reset successfuly"
        sendToken(patient, 200, res, message)




    } catch (error) {
       console.log(error)
        return res.status(500).json({
            success: false,
            error

        })
        
    }
}


const updatePasswordDoctor = async (req, res)=>{
    try {
       
        const {oldPassword, newPassword, confrimNewPassword} = req.body

        const doctor = await Doctor.findById(req.user.id)

        if(!doctor){
            return res.status(400).json({
                succes: false,
                message: "User not Found"
            })
        }

        if(newPassword !== confrimNewPassword){
            return res.status(400).json({
                succes: false,
                message: "password not match with each other"
            })
        }

        doctor.password = newPassword
        await doctor.save()

        const message = "Password successfully updated"
        sendToken(doctor, 200, res, message)


    } catch (error) {
        
        console.log(error)
        return res.status(500).json({
            succes: false,
            error
        })
    }
}






export {registerDoctor, loginDoctor, doctorProfile, updateDoctorProfile, deleteDoctorProfile, getAllDoctors, doctorLogout, resetPasswordRequest, resetPasswordDoctor, updatePasswordDoctor}