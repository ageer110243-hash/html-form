import { userInfo } from "os";
import Patient  from "../models/patientModel.js";
import { sendToken } from "../util/jwtToken.js";
import { sendEmail } from "../util/sendMaill.js";
import crypto from "crypto"
import console from "console";


const registerPatient = async (req, res)=>{
    try {
        
        const {name, email, phone, password , age, gender, disease,  bloodGroup} = req.body

        if(!name || !email ||!phone ||!password ||!age ||!gender ||!disease ||!bloodGroup){
            return res.status(400).json({
            
                success: false,
                message: "all inputs are required"


            })
        }

        const exitingPatient = await Patient.findOne({email});
        if(exitingPatient){
            return res.status(400).json({
                success: false,
                message: "Email already register "
            })
        }

      const patient = await Patient.create({
        name,
        email,
        phone,
        password,
        age,
        disease,
        gender,
        bloodGroup,

      })
       const message = "Patient Create Successfuly"
      sendToken(patient, 200, res, message)


    } catch (error) {
        console.log(error)
        return res.status(500).json({
           success: true,
            error,
        })
    }

}

const loginPatient = async (req, res)=>{
  try {
      
    const {email, password} = req.body
    if(!email ||!password){
        return res.status(400).json({
            success: false,
            message: "All inputs are required"
        })
    }

    const patient = await Patient.findOne({email})
    if(!patient){
        return res.status(400).json({
            success: false,
            message: "invalid credentials"
        })
    }

  const passwordMatched = await patient.comparePassword(password);
  if(!passwordMatched){

    return res.status(400).json({
        success: false,
        message: "invalid Crendentials"
    })
  };
  
   const message ="Patient login Successfuly"
 sendToken(patient, 200, res, message )



  } catch (error) {
    console.log(error)
    return res.status(500).json({
     success: false,
     error,

    })
  }
     
}

const patientProfile = async (req, res)=>{
    try {
        const patient = await Patient.findById(req.user.id);
    if(!patient){
        return res.status(400).json({
            success: true,
            message: "Patient Not Found"
        })
    }

    return res.status(200).json({
      success: true,
      patient,
    })

    } catch (error) {
        console.log(error)
        return res.status(500).json({
            success: false,
            error,
        })
    }
}

const updatePatient = async(req, res)=>{
    try {

        const patient = await Patient.findByIdAndUpdate(req.params.id, req.body,{
            runValidators : true,
            new: true

        })

        if(!patient){
            return res.status(400).json({
                success: false,
                message: "Paient Not Found"
            })
        }

        return res.status(200).json({
            success: true,
            message: "Patient Update SuccessFuly",
            patient
        })
        
    } catch (error) {

        console.log(error)
        return res.status(500).json({
            success: false,
            error
        })
    }
}

const deletePatient = async (req, res)=>{
    try {
       const patient = await Patient.findByIdAndDelete(req.params.id)
       if(!patient){
        return res.status(400).json({
           success: false,
           message: "Patient Not Found" 
        })
       }

       return res.status(200).json({
        success: true,
        message: "Patient Delete successfuly",

       })
    } catch (error) {
        console.log(error)
        return res.status(500).json({
            success: false,
            error
        })

    }
}

const getallPatients = async(req, res)=>{
    try {
        
        const patients = await Patient.find()

        if(!patients){
            return res.status(400).json({
                success: false,
                message: "Patients Not Found"
            })
        }
        return res.status(200).json({
            success: true,
            patients,
        })


    } catch (error) {
        console.log(error)
        return res.status(500).json({
            success: false,
            error
        })
    }
}

const patientLogout = async(req, res)=>{
    try {
        res.cookie("token", null, {
            expires : new Date(Date.now()),
            httpOnly: true
        })
 
        return res.status(200).json({
            success: true,
            message: "Patient loggedout successfully"
        })
    } catch (error) {
        console.log(error)
        return res.status(500).json({
            success: false,
            error
        })
    }
}

const resetPasswordRequest = async (req, res)=>{
    try {
        
        const {email} = req.body
        const patient = await Patient.findOne({email})
          
        if(!patient){
            return res.status(400).json({
                success: false,
                message: "User not Found"
            })
        }    

       let resetToken = patient.resetPassword() ;
       await patient.save();

       const resetPasswordUrl = `http://localhost:5173/reset-password/${resetToken}`

       const message= `if you want to reset your Password click on above link ${resetPasswordUrl}`
       await sendEmail({
        email: patient.email,
        subject : " ResetPassword Request",
        message
       })

       return res.status(200).json({
        success: true,
        message: `Email sent successfully to ${patient.email} `
       })

    } catch (error) {
        console.log(error)
        return res.status(500).json({
            success: false,
            error
        })
    }
}

  const resetPassword = async (req, res) =>{
    try {
        const resetPasswordToken = crypto.createHash("sha256").update(req.params.token).digest("hex");

        const patient = await Patient.findOne({
            resetPasswordToken,
            resetPasswordExpire :{ $gt : Date.now()}
        })

        if(!patient){
            return res.status(400).json({
                success: false,
                message: "invalid token"
            })
        }

        const { password, confrimPassword} = req.body;
        if(password !== confrimPassword){
            return res.status(400).json({
                success: false,
                message: "password does not match with each other"
            })
        }

        patient.password = password
        patient.resetPasswordExpire = undefined
        patient.resetPasswordToken = undefined

        await patient.save()
        
        const message = "password reset successfuly"
        sendToken(patient, 200, res, message)




    } catch (error) {
       console.log(error)
        return res.status(500).json({
            success: false,
            error

        })
        
    }
}
const updatePasswordPatient = async(req, res)=>{
  try {
      
    const {oldPassword, newPassword, confrimNewPassword} = req.body
    const patient = await Patient.findById(req.user.id)

    if(!patient){
        return res.status(400).json({
            success: false,
            message: " User Not Found"
        })
    }

    if(newPassword !== confrimNewPassword){
        return res.status(400).json({
            success: false,
            message: "Password not Match with Each other"
        })
    }



    patient.password = newPassword
    await patient.save()


    const message = "Password Update succussfuly"
    sendToken(patient, 200 , res, message)

  } catch (error) {

    console.log(error)
    return res.status(500).json({
        success: false,
        error

    })
  }
}



export {registerPatient, loginPatient, patientProfile, updatePatient, deletePatient, getallPatients, patientLogout, resetPasswordRequest, resetPassword, updatePasswordPatient}