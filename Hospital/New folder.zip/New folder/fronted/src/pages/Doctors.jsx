import DoctorHero from '../components/doctor/DoctorHero'
import DoctorList from '../components/doctor/DoctorList'

const Doctors = () => {
  return (
    <>
      <DoctorHero />
      <DoctorList/>

      {/* Yahan doctors ki list show hogi */}
    </>
  )
}

export default Doctors