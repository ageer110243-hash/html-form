import React from 'react'
import AboutHero from '../components/about/AboutHero'
import ContactHero from '../components/contact/ContactHero'
import ContactForm from '../components/contact/ContactForm'

const Contact = () => {
  return (
    <>
    <ContactHero/>
    <ContactForm/>
    </>
  )
}

export default Contact