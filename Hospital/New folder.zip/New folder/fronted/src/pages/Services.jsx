import React from 'react'
import ServiceHero from '../components/service/ServiceHero'
import ServiceList from '../components/service/ServiceList'

const Services = () => {
  return (
  <>
    <ServiceHero/>
    <ServiceList/>
    </>
  )
}

export default Services