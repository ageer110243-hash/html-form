import React from 'react'
import AboutHero from '../components/about/AboutHero'
import AboutContent from '../components/about/AboutContent'

const About = () => {
  return (
    <>
    <AboutHero/>
    <AboutContent/>
    </>
  )
}

export default About