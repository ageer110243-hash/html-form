
import React, { useState } from 'react'
import {
  Mail,
  Phone,
  MapPin,
  Clock,
  Send,
  MessageCircle,
  ArrowRight,
  Headset,
} from 'lucide-react'

const ContactForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  })

  const [submitted, setSubmitted] = useState(false)

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = (e) => {
    e.preventDefault()

    console.log('Contact Form Data:', formData)

    setSubmitted(true)

    setFormData({
      name: '',
      email: '',
      subject: '',
      message: '',
    })
  }

  return (
    <section id="contact-details" className="relative overflow-hidden bg-white">

      {/* Background Blobs */}
      <div className="pointer-events-none absolute -left-40 top-20 h-96 w-96 rounded-full bg-brand-100/60 blur-3xl" />
      <div className="pointer-events-none absolute -right-40 bottom-0 h-96 w-96 rounded-full bg-gold-300/20 blur-3xl" />

      <div className="container-x relative py-20 lg:py-28">

        {/* Section Heading */}
        <div className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">Contact us</span>

          <h2 className="mt-5 text-4xl font-semibold text-navy-900 sm:text-5xl">
            Let's start a
            <span className="block italic text-brand-600">
              conversation.
            </span>
          </h2>

          <p className="mt-5 leading-relaxed text-navy-800/70">
            We're happy to hear from you. Send us your questions,
            feedback, or concerns and our team will be ready to help.
          </p>
        </div>

        {/* Main Contact Section */}
        <div className="mt-16 grid gap-8 lg:grid-cols-[0.85fr_1.5fr]">

          {/* Left Contact Information */}
          <div className="relative overflow-hidden rounded-3xl bg-linear-to-br from-brand-700 via-brand-800 to-navy-900 p-8 shadow-2xl shadow-navy-900/15 sm:p-10">

            {/* Decorative Circle */}
            <div className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full bg-white/5" />
            <div className="pointer-events-none absolute -bottom-20 -left-20 h-64 w-64 rounded-full bg-gold-300/10" />

            <div className="relative">
              <span className="text-sm font-medium text-gold-300">
                Contact Information
              </span>

              <h3 className="mt-4 text-3xl font-semibold text-white">
                Get in touch with us.
              </h3>

              <p className="mt-4 leading-relaxed text-white/65">
                Have something on your mind? We'd love to hear from you.
                Contact our team through any of the following methods.
              </p>

              {/* Contact Details */}
              <div className="mt-12 space-y-8">

                {/* Email */}
                <div className="flex items-start gap-4">
                  <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-white/10 text-gold-300">
                    <Mail size={22} />
                  </span>

                  <div>
                    <p className="text-sm text-white/55">Email Us</p>
                    <p className="mt-1 break-all font-medium text-white">
                      support@yourwebsite.com
                    </p>
                  </div>
                </div>

                {/* Phone */}
                <div className="flex items-start gap-4">
                  <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-white/10 text-gold-300">
                    <Phone size={22} />
                  </span>

                  <div>
                    <p className="text-sm text-white/55">Call Us</p>
                    <p className="mt-1 font-medium text-white">
                      +92 300 1234567
                    </p>
                  </div>
                </div>

                {/* Address */}
                <div className="flex items-start gap-4">
                  <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-white/10 text-gold-300">
                    <MapPin size={22} />
                  </span>

                  <div>
                    <p className="text-sm text-white/55">Our Location</p>
                    <p className="mt-1 font-medium text-white">
                      Your City, Pakistan
                    </p>
                  </div>
                </div>

                {/* Working Hours */}
                <div className="flex items-start gap-4">
                  <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-white/10 text-gold-300">
                    <Clock size={22} />
                  </span>

                  <div>
                    <p className="text-sm text-white/55">Working Hours</p>
                    <p className="mt-1 font-medium text-white">
                      Monday - Saturday
                    </p>
                    <p className="mt-1 text-sm text-white/60">
                      9:00 AM - 6:00 PM
                    </p>
                  </div>
                </div>

              </div>

              {/* Bottom Message */}
              <div className="mt-14 flex items-center gap-3 border-t border-white/15 pt-7">
                <Headset className="text-gold-300" size={25} />

                <p className="text-sm text-white/70">
                  We're always ready to assist you.
                </p>
              </div>
            </div>
          </div>

          {/* Right Contact Form */}
          <div className="rounded-3xl border border-navy-900/5 bg-white p-7 shadow-xl shadow-navy-900/5 sm:p-10">

            <div className="mb-8">
              <span className="eyebrow">Send us a message</span>

              <h3 className="mt-4 text-3xl font-semibold text-navy-900">
                We'd love to hear from you.
              </h3>

              <p className="mt-3 text-sm leading-relaxed text-navy-800/60">
                Fill out the form below and let us know how we can help.
              </p>
            </div>

            {submitted && (
              <div className="mb-6 rounded-xl border border-green-200 bg-green-50 p-4 text-sm text-green-700">
                Your message has been submitted successfully!
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">

              {/* Name & Email */}
              <div className="grid gap-6 sm:grid-cols-2">

                <div>
                  <label className="mb-2 block text-sm font-semibold text-navy-900">
                    Full Name *
                  </label>

                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Enter your name"
                    required
                    className="w-full rounded-xl border border-navy-900/10 bg-brand-50/30 px-4 py-3.5 text-sm text-navy-900 outline-none transition placeholder:text-navy-800/35 focus:border-brand-600 focus:ring-4 focus:ring-brand-600/10"
                  />
                </div>

                <div>
                  <label className="mb-2 block text-sm font-semibold text-navy-900">
                    Email Address *
                  </label>

                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="example@gmail.com"
                    required
                    className="w-full rounded-xl border border-navy-900/10 bg-brand-50/30 px-4 py-3.5 text-sm text-navy-900 outline-none transition placeholder:text-navy-800/35 focus:border-brand-600 focus:ring-4 focus:ring-brand-600/10"
                  />
                </div>

              </div>

              {/* Subject */}
              <div>
                <label className="mb-2 block text-sm font-semibold text-navy-900">
                  Subject *
                </label>

                <input
                  type="text"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  placeholder="How can we help you?"
                  required
                  className="w-full rounded-xl border border-navy-900/10 bg-brand-50/30 px-4 py-3.5 text-sm text-navy-900 outline-none transition placeholder:text-navy-800/35 focus:border-brand-600 focus:ring-4 focus:ring-brand-600/10"
                />
              </div>

              {/* Message */}
              <div>
                <label className="mb-2 block text-sm font-semibold text-navy-900">
                  Your Message *
                </label>

                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Write your message here..."
                  rows="6"
                  required
                  className="w-full resize-none rounded-xl border border-navy-900/10 bg-brand-50/30 px-4 py-3.5 text-sm text-navy-900 outline-none transition placeholder:text-navy-800/35 focus:border-brand-600 focus:ring-4 focus:ring-brand-600/10"
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="btn-primary flex w-full items-center justify-center gap-3"
              >
                Send Message
                <Send size={18} />
              </button>

              <p className="text-center text-xs text-navy-800/45">
                Your information will be kept private and secure.
              </p>

            </form>
          </div>

        </div>
      </div>
    </section>
  )
}

export default ContactForm
