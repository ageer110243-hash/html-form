
import React from 'react'
import { Link } from 'react-router-dom'
import {
  ArrowRight,
  Mail,
  Phone,
  MapPin,
  MessageCircle,
  Clock,
  Headset,
} from 'lucide-react'

const ContactHero = () => {
  return (
    <section className="relative overflow-hidden">

      {/* Background Blobs */}
      <div className="pointer-events-none absolute -left-40 top-0 h-[28rem] w-[28rem] rounded-full bg-brand-100 blur-3xl" />
      <div className="pointer-events-none absolute right-0 top-20 h-96 w-96 rounded-full bg-gold-300/30 blur-3xl" />

      <div className="container-x relative grid items-center gap-14 py-16 lg:grid-cols-2 lg:py-24">

        {/* Left Content */}
        <div>
          <span className="eyebrow">Get in touch</span>

          <h1 className="mt-5 text-5xl font-semibold leading-[1.05] text-navy-900 sm:text-6xl">
            We're here
            <span className="block italic text-brand-600">
              to help you.
            </span>
          </h1>

          <p className="mt-6 max-w-xl text-lg leading-relaxed text-navy-800/70">
            Have questions or need assistance? Our team is always ready
            to help you. Reach out to us for appointments, healthcare
            information, or any other support.
          </p>

          <div className="mt-9 flex flex-wrap items-center gap-4">
            <a href="#contact-details" className="btn-primary">
              <MessageCircle size={18} />
              Contact Us
              <ArrowRight size={18} />
            </a>
          </div>

          {/* Contact Highlights */}
          <div className="mt-12 flex flex-wrap items-center gap-x-8 gap-y-4 text-sm text-navy-800/80">

            <div className="flex items-center gap-2">
              <Clock size={20} className="text-brand-600" />
              Support Available
            </div>

            <div className="flex items-center gap-2">
              <Headset size={20} className="text-brand-600" />
              We're Here For You
            </div>

          </div>
        </div>

        {/* Right Visual */}
        <div className="relative mx-auto w-full max-w-md">

          <div className="relative aspect-4/5 overflow-hidden rounded-t-[12rem] rounded-b-3xl bg-linear-to-br from-brand-600 via-brand-800 to-navy-900 shadow-2xl shadow-navy-900/30">

            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-20 [background-image:radial-gradient(circle_at_1px_1px,white_1px,transparent_0)] [background-size:22px_22px]" />

            {/* Main Icon */}
            <MessageCircle
              className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-white/15"
              size={240}
              strokeWidth={1}
            />

            <Mail
              className="absolute right-16 top-24 text-white/20"
              size={48}
              strokeWidth={1}
            />

            <Phone
              className="absolute bottom-36 left-14 text-white/20"
              size={40}
              strokeWidth={1}
            />

            {/* Bottom Text */}
            <div className="absolute inset-x-0 bottom-0 bg-linear-to-t from-navy-950/80 to-transparent p-8 pt-24">
              <p className="font-display text-2xl italic text-white">
                "We're just a message away."
              </p>
            </div>

          </div>

          {/* Gold Ring */}
          <div className="pointer-events-none absolute -right-5 -top-5 h-full w-full rounded-t-[12rem] rounded-b-3xl border border-gold-500/50" />

          {/* Floating Card */}
          <div className="absolute -left-6 top-24 flex items-center gap-3 rounded-2xl bg-white p-4 shadow-xl shadow-navy-900/10 sm:-left-12">

            <span className="grid h-11 w-11 place-items-center rounded-xl bg-brand-50 text-brand-600">
              <Headset size={20} />
            </span>

            <div>
              <p className="text-xs text-navy-800/60">
                Need assistance?
              </p>

              <p className="text-sm font-semibold text-navy-900">
                We're Here To Help
              </p>
            </div>

          </div>

        </div>
      </div>
    </section>
  )
}

export default ContactHero
