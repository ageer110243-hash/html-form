
import React from 'react'
import {
  HeartPulse,
  Target,
  Eye,
  ShieldCheck,
  Stethoscope,
  Users,
  Award,
  Activity,
  ArrowRight,
} from 'lucide-react'
import { Link } from 'react-router-dom'

const AboutContent = () => {
  return (
    <section className="relative overflow-hidden bg-white">

      {/* Background Blobs */}
      <div className="pointer-events-none absolute -right-40 top-20 h-96 w-96 rounded-full bg-brand-100/60 blur-3xl" />
      <div className="pointer-events-none absolute -left-40 bottom-0 h-96 w-96 rounded-full bg-gold-300/20 blur-3xl" />

      <div className="container-x relative py-20 lg:py-28">

        {/* Section Heading */}
        <div className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">About our platform</span>

          <h2 className="mt-5 text-4xl font-semibold leading-tight text-navy-900 sm:text-5xl">
            Healthcare made
            <span className="block italic text-brand-600">
              simple for everyone.
            </span>
          </h2>

          <p className="mt-5 leading-relaxed text-navy-800/70">
            We are committed to connecting patients with trusted medical
            professionals and making healthcare easier, faster, and more
            accessible.
          </p>
        </div>

        {/* Mission & Vision */}
        <div className="mt-16 grid gap-7 lg:grid-cols-2">

          {/* Mission */}
          <div className="group relative overflow-hidden rounded-3xl bg-linear-to-br from-brand-700 to-navy-900 p-8 shadow-xl shadow-navy-900/10 sm:p-10">

            <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/5" />

            <div className="relative grid h-14 w-14 place-items-center rounded-2xl bg-white/15 text-white">
              <Target size={29} />
            </div>

            <h3 className="relative mt-7 text-2xl font-semibold text-white">
              Our Mission
            </h3>

            <p className="relative mt-4 leading-relaxed text-white/75">
              Our mission is to provide accessible, reliable, and quality
              healthcare services. We aim to make it easier for patients
              to find doctors, book appointments, and receive the care
              they deserve.
            </p>

          </div>

          {/* Vision */}
          <div className="group relative overflow-hidden rounded-3xl border border-navy-900/5 bg-brand-50/60 p-8 shadow-lg shadow-navy-900/5 sm:p-10">

            <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-gold-300/20" />

            <div className="relative grid h-14 w-14 place-items-center rounded-2xl bg-gold-300/30 text-brand-700">
              <Eye size={29} />
            </div>

            <h3 className="relative mt-7 text-2xl font-semibold text-navy-900">
              Our Vision
            </h3>

            <p className="relative mt-4 leading-relaxed text-navy-800/70">
              Our vision is to build a healthier community where everyone
              can access professional medical guidance, trusted doctors,
              and a better healthcare experience.
            </p>

          </div>
        </div>

        {/* Why Choose Us */}
        <div className="mt-28">

          <div className="max-w-2xl">
            <span className="eyebrow">Why choose us</span>

            <h2 className="mt-5 text-4xl font-semibold text-navy-900 sm:text-5xl">
              Care that makes
              <span className="italic text-brand-600"> a difference.</span>
            </h2>

            <p className="mt-5 leading-relaxed text-navy-800/70">
              We focus on making every step of your healthcare journey
              comfortable, convenient, and trustworthy.
            </p>
          </div>

          {/* Feature Cards */}
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">

            {/* Card 1 */}
            <div className="rounded-3xl border border-navy-900/5 bg-white p-7 shadow-lg shadow-navy-900/5 transition duration-300 hover:-translate-y-2">
              <div className="grid h-14 w-14 place-items-center rounded-2xl bg-brand-50 text-brand-600">
                <Stethoscope size={27} />
              </div>

              <h3 className="mt-6 text-lg font-semibold text-navy-900">
                Expert Doctors
              </h3>

              <p className="mt-3 text-sm leading-relaxed text-navy-800/65">
                Connect with experienced doctors from different medical
                departments.
              </p>
            </div>

            {/* Card 2 */}
            <div className="rounded-3xl border border-navy-900/5 bg-white p-7 shadow-lg shadow-navy-900/5 transition duration-300 hover:-translate-y-2">
              <div className="grid h-14 w-14 place-items-center rounded-2xl bg-gold-300/20 text-gold-600">
                <ShieldCheck size={27} />
              </div>

              <h3 className="mt-6 text-lg font-semibold text-navy-900">
                Trusted Services
              </h3>

              <p className="mt-3 text-sm leading-relaxed text-navy-800/65">
                We prioritize patient safety, privacy, and dependable
                healthcare services.
              </p>
            </div>

            {/* Card 3 */}
            <div className="rounded-3xl border border-navy-900/5 bg-white p-7 shadow-lg shadow-navy-900/5 transition duration-300 hover:-translate-y-2">
              <div className="grid h-14 w-14 place-items-center rounded-2xl bg-brand-50 text-brand-600">
                <CalendarCheckIcon />
              </div>

              <h3 className="mt-6 text-lg font-semibold text-navy-900">
                Easy Appointments
              </h3>

              <p className="mt-3 text-sm leading-relaxed text-navy-800/65">
                Book your medical appointments quickly and conveniently.
              </p>
            </div>

            {/* Card 4 */}
            <div className="rounded-3xl border border-navy-900/5 bg-white p-7 shadow-lg shadow-navy-900/5 transition duration-300 hover:-translate-y-2">
              <div className="grid h-14 w-14 place-items-center rounded-2xl bg-gold-300/20 text-gold-600">
                <HeartPulse size={27} />
              </div>

              <h3 className="mt-6 text-lg font-semibold text-navy-900">
                Patient First
              </h3>

              <p className="mt-3 text-sm leading-relaxed text-navy-800/65">
                Your health, comfort, and satisfaction are always our
                priority.
              </p>
            </div>

          </div>
        </div>

        {/* Bottom CTA */}
        <div className="relative mt-28 overflow-hidden rounded-3xl bg-linear-to-r from-brand-700 via-brand-800 to-navy-900 px-8 py-14 text-center shadow-2xl shadow-navy-900/15 sm:px-16">

          <div className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full bg-gold-300/20 blur-3xl" />

          <div className="relative">
            <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-white/15 text-white">
              <Activity size={32} />
            </div>

            <h2 className="mt-6 text-3xl font-semibold text-white sm:text-4xl">
              Ready to take care of your health?
            </h2>

            <p className="mx-auto mt-4 max-w-xl leading-relaxed text-white/70">
              Start your healthcare journey with us. Find the right doctor
              and book your appointment today.
            </p>

            <Link
              to="/patient-signup"
              className="btn-primary mt-8 inline-flex"
            >
              Get Started
              <ArrowRight size={18} />
            </Link>
          </div>

        </div>

      </div>
    </section>
  )
}

const CalendarCheckIcon = () => (
  <Award size={27} />
)

export default AboutContent
