import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'

// the doctor model stores these spellings, show the correct ones to visitors
const specializationLabels = {
  Dermatlogist: 'Dermatologist',
  Cardialogist: 'Cardiologist',
  Phychologist: 'Psychologist',
}
const labelOf = (specialization) => specializationLabels[specialization] || specialization

const initialsOf = (name = '') =>
  name
    .replace(/^Dr\.?\s*/i, '')
    .split(' ')
    .map((w) => w[0])
    .slice(0, 2)
    .join('')
    .toUpperCase()

const DoctorList = () => {
  const [doctors, setDoctors] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [selected, setSelected] = useState('All') // specialization chip

  const getAllDoctor = async () => {
    try {
      // public route: approved doctors only, no login needed
      const respone = await axios.get('http://localhost:8000/api/doctor/getAll-doctors')
      setDoctors(respone.data.doctors)
    } catch (error) {
      console.log(error)
      setError('Could not load the doctors. Please try again later.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    getAllDoctor()
  }, [])

  // chips: every specialization that exists in the list
  const specializations = ['All', ...new Set(doctors.map((d) => d.specialization))]
  const visible = selected === 'All' ? doctors : doctors.filter((d) => d.specialization === selected)

  return (
    <section className="py-16 lg:py-24">
      <div className="container-x">
        <div className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">Our specialists</span>
          <h2 className="mt-4 text-4xl font-semibold leading-tight text-navy-900 sm:text-5xl">
            Find the right <span className="italic text-brand-600">doctor for you</span>
          </h2>
          <p className="mt-4 text-navy-800/70">Experienced, approved doctors across every department.</p>
        </div>

        {/* specialization filter */}
        {specializations.length > 2 && (
          <div className="mt-10 flex flex-wrap justify-center gap-3">
            {specializations.map((s) => (
              <button
                key={s}
                onClick={() => setSelected(s)}
                className={`rounded-full border px-5 py-2 text-sm font-semibold transition ${
                  selected === s
                    ? 'border-brand-700 bg-brand-700 text-white shadow-md shadow-brand-900/20'
                    : 'border-navy-900/10 bg-white text-navy-800 hover:border-brand-600 hover:text-brand-700'
                }`}
              >
                {s === 'All' ? 'All' : labelOf(s)}
              </button>
            ))}
          </div>
        )}

        {/* states */}
        {loading && <p className="mt-14 text-center text-navy-800/60">Loading doctors...</p>}
        {error && <p className="mt-14 text-center font-semibold text-red-600">{error}</p>}
        {!loading && !error && visible.length === 0 && (
          <p className="mt-14 text-center text-navy-800/60">No doctors available right now.</p>
        )}

        {/* doctors */}
        <div className="mt-14 grid gap-7 sm:grid-cols-2 lg:grid-cols-4">
          {visible.map((d) => (
            <article
              key={d._id}
              className="group overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-navy-900/5 transition hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-navy-900/10"
            >
              <div className="grid h-52 place-items-center bg-linear-to-br from-brand-100 to-brand-200">
                <span className="grid h-28 w-28 place-items-center rounded-full bg-linear-to-br from-brand-600 to-navy-800 font-display text-4xl font-bold text-white ring-4 ring-white">
                  {initialsOf(d.name)}
                </span>
              </div>
              <div className="p-6 text-center">
                <h3 className="text-2xl font-semibold">{d.name}</h3>
                <p className="mt-1 text-sm font-medium text-brand-600">{labelOf(d.specialization)}</p>
                {d.experience != null && (
                  <p className="text-xs text-navy-800/60">{d.experience} years experience</p>
                )}
                <Link to="/patient-dashboard/book-appointment" className="btn-outline mt-5 w-full py-2.5">
                  Book now
                </Link>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

export default DoctorList