
import React from 'react'
import { Link } from 'react-router-dom'
import {
  Stethoscope,
  HeartPulse,
  Brain,
  Baby,
  Smile,
  Microscope,
  ArrowUpRight,
  CalendarCheck,
  Activity,
  ShieldCheck,
} from 'lucide-react'

const services = [
  {
    icon: Stethoscope,
    title: 'General Checkup',
    description:
      'Complete health examinations and routine medical consultations to help you maintain a healthy lifestyle.',
    number: '01',
  },
  {
    icon: HeartPulse,
    title: 'Cardiology',
    description:
      'Professional heart health consultations, cardiovascular checkups, and personalized treatment guidance.',
    number: '02',
  },
  {
    icon: Brain,
    title: 'Neurology',
    description:
      'Specialized medical consultations for brain, nerve, and neurological health conditions.',
    number: '03',
  },
  {
    icon: Baby,
    title: 'Pediatrics',
    description:
      'Dedicated healthcare services for infants, children, and growing families.',
    number: '04',
  },
  {
    icon: Smile,
    title: 'Dental Care',
    description:
      'Complete dental checkups, oral hygiene guidance, and professional dental care services.',
    number: '05',
  },
  {
    icon: Microscope,
    title: 'Laboratory Services',
    description:
      'Reliable diagnostic testing and laboratory services to support accurate medical decisions.',
    number: '06',
  },
]

const ServiceList = () => {
  return (
    <section className="relative overflow-hidden bg-white">

      {/* Background Blobs */}
      <div className="pointer-events-none absolute -left-40 top-20 h-96 w-96 rounded-full bg-brand-100/50 blur-3xl" />
      <div className="pointer-events-none absolute -right-40 bottom-0 h-96 w-96 rounded-full bg-gold-300/20 blur-3xl" />

      <div className="container-x relative py-20 lg:py-28">

        {/* Section Heading */}
        <div className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">What we offer</span>

          <h2 className="mt-5 text-4xl font-semibold leading-tight text-navy-900 sm:text-5xl">
            Our medical
            <span className="block italic text-brand-600">
              services.
            </span>
          </h2>

          <p className="mt-5 leading-relaxed text-navy-800/70">
            Explore our range of healthcare services, designed to provide
            quality medical attention and personalized care for every patient.
          </p>
        </div>

        {/* Services Grid */}
        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">

          {services.map((service) => {
            const Icon = service.icon

            return (
              <div
                key={service.number}
                className="group relative overflow-hidden rounded-3xl border border-navy-900/5 bg-white p-8 shadow-lg shadow-navy-900/5 transition-all duration-300 hover:-translate-y-2 hover:border-brand-600/20 hover:shadow-xl hover:shadow-brand-900/10"
              >

                {/* Card Number */}
                <span className="absolute right-7 top-7 text-4xl font-semibold text-navy-900/5">
                  {service.number}
                </span>

                {/* Icon */}
                <div className="grid h-16 w-16 place-items-center rounded-2xl bg-brand-50 text-brand-600 transition-all duration-300 group-hover:bg-brand-600 group-hover:text-white">
                  <Icon size={29} strokeWidth={1.8} />
                </div>

                {/* Content */}
                <h3 className="mt-7 text-xl font-semibold text-navy-900 transition-colors group-hover:text-brand-600">
                  {service.title}
                </h3>

                <p className="mt-4 min-h-[84px] text-sm leading-relaxed text-navy-800/65">
                  {service.description}
                </p>

                {/* Bottom Link */}
                <Link
                  to="/patient-signup"
                  className="mt-7 inline-flex items-center gap-2 text-sm font-semibold text-brand-600 transition-all hover:gap-3"
                >
                  Book Appointment
                  <ArrowUpRight size={18} />
                </Link>

                {/* Bottom Accent */}
                <div className="absolute bottom-0 left-0 h-1 w-0 bg-gold-500 transition-all duration-500 group-hover:w-full" />

              </div>
            )
          })}

        </div>

        {/* Bottom Information */}
        <div className="mt-16 grid gap-6 rounded-3xl bg-brand-50/70 p-8 sm:grid-cols-3 sm:p-10">

          <div className="flex items-center gap-4">
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-white text-brand-600 shadow-sm">
              <ShieldCheck size={24} />
            </span>

            <div>
              <h4 className="font-semibold text-navy-900">
                Trusted Care
              </h4>
              <p className="mt-1 text-sm text-navy-800/60">
                Patient-focused services
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-white text-brand-600 shadow-sm">
              <Activity size={24} />
            </span>

            <div>
              <h4 className="font-semibold text-navy-900">
                Quality Healthcare
              </h4>
              <p className="mt-1 text-sm text-navy-800/60">
                Professional medical support
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-white text-brand-600 shadow-sm">
              <CalendarCheck size={24} />
            </span>

            <div>
              <h4 className="font-semibold text-navy-900">
                Easy Booking
              </h4>
              <p className="mt-1 text-sm text-navy-800/60">
                Simple online appointments
              </p>
            </div>
          </div>

        </div>

        {/* CTA */}
        <div className="mt-16 text-center">
          <h3 className="text-2xl font-semibold text-navy-900 sm:text-3xl">
            Need help choosing a service?
          </h3>

          <p className="mt-3 text-navy-800/65">
            Our healthcare team is ready to help you find the right care.
          </p>

          <Link
            to="/contact"
            className="btn-primary mt-7 inline-flex"
          >
            Contact Our Team
            <ArrowUpRight size={18} />
          </Link>
        </div>

      </div>
    </section>
  )
}

export default ServiceList
