
import React from 'react'
import { Link } from 'react-router-dom'
import {
  ArrowRight,
  HeartPulse,
  ShieldCheck,
  Stethoscope,
  CalendarCheck,
  Activity,
  Microscope,
} from 'lucide-react'

const ServiceHero = () => {
  return (
    <section className="relative overflow-hidden">

      {/* Background Blobs */}
      <div className="pointer-events-none absolute -left-40 top-0 h-[28rem] w-[28rem] rounded-full bg-brand-100 blur-3xl" />
      <div className="pointer-events-none absolute right-0 top-20 h-96 w-96 rounded-full bg-gold-300/30 blur-3xl" />

      <div className="container-x relative grid items-center gap-14 py-16 lg:grid-cols-2 lg:py-24">

        {/* Left Content */}
        <div>
          <span className="eyebrow">Our healthcare services</span>

          <h1 className="mt-5 text-5xl font-semibold leading-[1.05] text-navy-900 sm:text-6xl">
            Complete care,
            <span className="block italic text-brand-600">
              for better health.
            </span>
          </h1>

          <p className="mt-6 max-w-xl text-lg leading-relaxed text-navy-800/70">
            Your health deserves the best attention. We provide a range
            of healthcare services designed to make your medical journey
            easier, safer, and more comfortable.
          </p>

          <p className="mt-4 max-w-xl leading-relaxed text-navy-800/70">
            From expert consultations to personalized treatment, our
            dedicated medical professionals are here to support your
            health at every step.
          </p>

          {/* CTA Button */}
          <div className="mt-9 flex flex-wrap items-center gap-4">
            <Link to="/patient-signup" className="btn-primary">
              <CalendarCheck size={18} />
              Book an Appointment
              <ArrowRight size={18} />
            </Link>
          </div>

          {/* Trust Points */}
          <div className="mt-12 flex flex-wrap items-center gap-x-8 gap-y-4 text-sm text-navy-800/80">

            <div className="flex items-center gap-2">
              <ShieldCheck size={20} className="text-brand-600" />
              Quality Medical Care
            </div>

            <div className="flex items-center gap-2">
              <UsersIcon />
              Patient Focused Services
            </div>

          </div>
        </div>

        {/* Right Visual */}
        <div className="relative mx-auto w-full max-w-md">

          <div className="relative aspect-4/5 overflow-hidden rounded-t-[12rem] rounded-b-3xl bg-linear-to-br from-brand-600 via-brand-800 to-navy-900 shadow-2xl shadow-navy-900/30">

            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-20 [background-image:radial-gradient(circle_at_1px_1px,white_1px,transparent_0)] [background-size:22px_22px]" />

            {/* Main Icon */}
            <HeartPulse
              className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-white/15"
              size={240}
              strokeWidth={1}
            />

            <Microscope
              className="absolute right-14 top-24 text-white/20"
              size={55}
              strokeWidth={1}
            />

            <Activity
              className="absolute bottom-36 left-14 text-white/20"
              size={45}
              strokeWidth={1}
            />

            {/* Bottom Text */}
            <div className="absolute inset-x-0 bottom-0 bg-linear-to-t from-navy-950/80 to-transparent p-8 pt-24">
              <p className="font-display text-2xl italic text-white">
                "Better healthcare, healthier lives."
              </p>
            </div>

          </div>

          {/* Gold Ring */}
          <div className="pointer-events-none absolute -right-5 -top-5 h-full w-full rounded-t-[12rem] rounded-b-3xl border border-gold-500/50" />

          {/* Floating Card */}
          <div className="absolute -left-6 top-24 flex items-center gap-3 rounded-2xl bg-white p-4 shadow-xl shadow-navy-900/10 sm:-left-12">

            <span className="grid h-11 w-11 place-items-center rounded-xl bg-brand-50 text-brand-600">
              <Stethoscope size={20} />
            </span>

            <div>
              <p className="text-xs text-navy-800/60">
                Our commitment
              </p>

              <p className="text-sm font-semibold text-navy-900">
                Complete Patient Care
              </p>
            </div>

          </div>

        </div>
      </div>
    </section>
  )
}

const UsersIcon = () => (
  <Activity size={20} className="text-brand-600" />
)

export default ServiceHero
